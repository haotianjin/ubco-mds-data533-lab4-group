from setuptools import setup,find_packages

setup(
    name="HospitalManagement",
    version='0.1',
    packages=find_packages(exclude=['tests*']),
    license='MIT',
    description='A test python package',
    url='https://github.com/haotianjin/ubco-mds-data533-lab4-group.git',
    author='Haotian Jin, Zhiyan Ma',
    author_email='mzy1997@student.ubc.ca'
)